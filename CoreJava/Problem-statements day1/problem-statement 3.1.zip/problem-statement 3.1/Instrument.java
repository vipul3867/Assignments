package problem_statement_1;
public abstract class Instrument {
	public abstract void play();
}
