package problem_statement_1;
public class Flute extends Instrument {

		public void play() {
			System.out.println("Flute is playing  toot toot toot toot");

		}

	}

