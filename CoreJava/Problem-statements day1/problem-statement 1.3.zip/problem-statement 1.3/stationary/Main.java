package stationary;

public class Main {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
     Book b1= new Book("Java Programming ",350.50);
     Book b2=new Book("Let Us C ",200.00);
     b1.display();
     b2.display();
     	
	}

}
